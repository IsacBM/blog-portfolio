// Isac B.M - 2K23
const http = require('node:http');
const fs = require('node:fs');
const querystring = require('node:querystring');
const express = require('express');
const app = express();
const Database = require('better-sqlite3');
const db = new Database('static/schema.sql');
const EventEmitter = require('eventemitter3');
const eventEmitter = new EventEmitter();

class CustomEvent {
  constructor(event, params) {
    this.event = event;
    this.params = params;
  }
}

global.CustomEvent = CustomEvent;

// ... seu código restante aqui

// ... código para atualizar a posição do ônibus no banco de dados

// Emitir um evento para notificar a alteração na posição do ônibus
eventEmitter.emit('busPositionChange', { lat: newLat, lng: newLng });


var newLat = -9.040854
var newLng = -42.691095
var busId = 1

// Supondo que a tabela se chame 'bus_position'
const statement = db.prepare('UPDATE Bus_location SET lat = ?, lnt = ? WHERE id = ?');
const result = statement.run(newLat, newLng, busId);
// Verifique se a atualização foi bem-sucedida
if (result.changes === 1) {
  console.log('Posição do ônibus atualizada com sucesso');
} else {
  console.log('Falha ao atualizar a posição do ônibus');
}

// Emitir um evento para notificar a alteração na posição do ônibus
const busPositionChangeEvent = new CustomEvent('busPositionChange', {
  detail: {
    lat: newLat,
    lng: newLng
  }
});
document.dispatchEvent(busPositionChangeEvent);

// Close the database connection
db.close();


app.use(express.static('public'));
const porta_Server = process.env.PORT;

function pegarDataAtual() {
  data = new Date();
  document.getElementById('data').value = data.getDay() + '/' + data.getMonth() + '/' + data.getFullYear();
}

const server = http.createServer((req, res) => {
  fs.readFile('static/public/index.html', (err, arquivo_html) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(arquivo_html);
    res.end();
  });
});
server.listen(porta_Server, () => {
  console.log(`Servidor na Ativa: ${porta_Server}/`)
});