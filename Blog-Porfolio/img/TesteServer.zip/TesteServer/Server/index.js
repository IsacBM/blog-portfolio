// Isac B.M - 2K23
const http = require('node:http');
const fs = require('node:fs');
const querystring = require('node:querystring');
const express = require('express'); 
const app = express(); 
//const Database = require('node:better-sqlite3');

//const db = new Database('database.sqlite3');
//db.pragma('journal_mode = WAL');

//fs.readFile('static/esquema.sql', (err, sql) => {
  
//});

app.use(express.static('public'));
const porta_Server = process.env.PORT;

function pegarDataAtual() {
  data = new Date();
  document.getElementById('data').value = data.getDay() + '/' + data.getMonth() + '/' + data.getFullYear();
}

const server = http.createServer((req, res) => {
  fs.readFile('static/public/index.html', (err, arquivo_html) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(arquivo_html);
    res.end();
  });
});
server.listen(porta_Server, () => {
  console.log(`Servidor na Ativa: http://${porta_Server}/`)
});